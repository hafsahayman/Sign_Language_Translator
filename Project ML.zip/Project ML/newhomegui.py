
from PyQt5 import QtCore, QtGui, QtWidgets
from newtraingui import Ui_TrainWindow

class Ui_HomeWindow(object):
    def OpensWindow(self):
        self.window = QtWidgets.QMainWindow()
        self.ui = Ui_TrainWindow()
        self.ui.setupUi(self.window)
        self.window.show()

    def setupUi(self, HomeWindow):
        HomeWindow.setObjectName("HomeWindow")
        HomeWindow.resize(554, 286)
        self.centralwidget = QtWidgets.QWidget(HomeWindow)
        self.centralwidget.setAutoFillBackground(False)
        self.centralwidget.setStyleSheet("background:rgba(0,0,0,0);")
        self.centralwidget.setObjectName("centralwidget")
        self.main_frame = QtWidgets.QFrame(self.centralwidget)
        self.main_frame.setGeometry(QtCore.QRect(10, 90, 531, 181))
        self.main_frame.setStyleSheet("background:#212F84;\n"
                                      "border-radius:20px;\n"
                                      "box-shadow: 5px 10px #D5D5D6;\n"
                                      "\n"
                                      "")
        self.main_frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.main_frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.main_frame.setObjectName("main_frame")
        self.train = QtWidgets.QPushButton(self.main_frame, clicked= lambda :self.OpensWindow())
        self.train.setGeometry(QtCore.QRect(40, 60, 131, 61))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.train.setFont(font)
        self.train.setStyleSheet("QPushButton#train{\n"
                                 " color:#212F84;\n"
                                 "text-align:center;\n"
                                 "background:#fff;\n"
                                 "border-radius:4px;\n"
                                 "border-color:#212F84;\n"
                                 "}\n"
                                 "QPushButton#train:hover{\n"
                                 "color:#212F84;\n"
                                 "text-align:center;\n"
                                 "border-radius:4px;\n"
                                 "background:#DCDCDC;\n"
                                 "}\n"
                                 "QPushButton#train:pressed{\n"
                                 " color:green;\n"
                                 "text-align:center;\n"
                                 "background:#DCDCDC;\n"
                                 "border-radius:4px;\n"
                                 "\n"
                                 "}\n"
                                 "\n"
                                 "\n"
                                 "\n"
                                 "\n"
                                 "\n"
                                 "")
        self.train.setObjectName("train")
        self.test = QtWidgets.QPushButton(self.main_frame)
        self.test.setGeometry(QtCore.QRect(190, 60, 141, 61))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.test.setFont(font)
        self.test.setStyleSheet("QPushButton#test{\n"
                                " color:#212F84;\n"
                                "text-align:center;\n"
                                "background:#fff;\n"
                                "border-radius:4px;\n"
                                "border-color:#212F84;\n"
                                "}\n"
                                "QPushButton#test:hover{\n"
                                "color:#212F84;\n"
                                "text-align:center;\n"
                                "border-radius:4px;\n"
                                "background:#DCDCDC;\n"
                                "}\n"
                                "QPushButton#test:pressed{\n"
                                " color:green;\n"
                                "text-align:center;\n"
                                "background:#DCDCDC;\n"
                                "border-radius:4px;\n"
                                "\n"
                                "}\n"
                                "\n"
                                "\n"
                                "\n"
                                "\n"
                                "\n"
                                "")
        self.test.setObjectName("test")
        self.check = QtWidgets.QPushButton(self.main_frame)
        self.check.setGeometry(QtCore.QRect(350, 60, 141, 61))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.check.setFont(font)
        self.check.setStyleSheet("QPushButton#check{\n"
                                 " color:#212F84;\n"
                                 "text-align:center;\n"
                                 "background:#fff;\n"
                                 "border-radius:4px;\n"
                                 "border-color:#212F84;\n"
                                 "}\n"
                                 "QPushButton#check:hover{\n"
                                 "color:#212F84;\n"
                                 "text-align:center;\n"
                                 "border-radius:4px;\n"
                                 "background:#DCDCDC;\n"
                                 "}\n"
                                 "QPushButton#check:pressed{\n"
                                 " color:green;\n"
                                 "text-align:center;\n"
                                 "background:#DCDCDC;\n"
                                 "border-radius:4px;\n"
                                 "\n"
                                 "}\n"
                                 "\n"
                                 "\n"
                                 "\n"
                                 "\n"
                                 "\n"
                                 "")
        self.check.setObjectName("check")
        self.close = QtWidgets.QPushButton(self.main_frame)
        self.close.setGeometry(QtCore.QRect(490, 10, 31, 21))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(14)
        self.close.setFont(font)
        self.close.setStyleSheet("QPushButton#close{\n"
                                 " color:#fff;\n"
                                 "text-align:center;\n"
                                 "background:#212F84;\n"
                                 "border-radius:4px;\n"
                                 "border-color:#212F84;\n"
                                 "}\n"
                                 "QPushButton#close:pressed{\n"
                                 " color:green;\n"
                                 "text-align:center;\n"
                                 "background:#DCDCDC;\n"
                                 "border-radius:4px;\n"
                                 "\n"
                                 "}\n"
                                 "\n"
                                 "\n"
                                 "\n"
                                 "\n"
                                 "\n"
                                 "")
        self.close.setObjectName("close")
        self.hands = QtWidgets.QFrame(self.centralwidget)
        self.hands.setGeometry(QtCore.QRect(40, 10, 461, 131))
        self.hands.setStyleSheet("image: url(:/img/welcome.png);\n"
                                 "")
        self.hands.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.hands.setFrameShadow(QtWidgets.QFrame.Raised)
        self.hands.setObjectName("hands")
        HomeWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(HomeWindow)
        QtCore.QMetaObject.connectSlotsByName(HomeWindow)

    def retranslateUi(self, HomeWindow):
        _translate = QtCore.QCoreApplication.translate
        HomeWindow.setWindowTitle(_translate("HomeWindow", "MainWindow"))
        self.train.setText(_translate("HomeWindow", "TRAIN"))
        self.test.setText(_translate("HomeWindow", "TEST"))
        self.check.setText(_translate("HomeWindow", "CHECK SIGNS"))
        self.close.setText(_translate("HomeWindow", "X"))


import hand_rc

if __name__ == "__main__":
    import sys

    app = QtWidgets.QApplication(sys.argv)
    HomeWindow = QtWidgets.QMainWindow()
    ui = Ui_HomeWindow()
    ui.setupUi(HomeWindow)
    HomeWindow.show()
    sys.exit(app.exec_())
