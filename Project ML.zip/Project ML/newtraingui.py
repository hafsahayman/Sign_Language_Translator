
from PyQt5 import QtCore, QtGui, QtWidgets



class Ui_TrainWindow(object):
    def BackWindow(self):
        from newhomegui import Ui_HomeWindow
        self.window2 = QtWidgets.QMainWindow()
        self.ui = Ui_HomeWindow()
        self.ui.setupUi(self.window2)
        self.window2.show()
    def setupUi(self, TrainWindow):
        TrainWindow.setObjectName("TrainWindow")
        TrainWindow.resize(811, 600)
        TrainWindow.setStyleSheet("background-color:#fff;")
        self.centralwidget = QtWidgets.QWidget(TrainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(-50, 10, 931, 541))
        self.label.setStyleSheet("image: url(:/img/instructions.jpg);")
        self.label.setText("")
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(0, -1, 811, 61))
        self.label_2.setStyleSheet("background:#212F84;")
        self.label_2.setText("")
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(0, 530, 811, 71))
        self.label_3.setStyleSheet("background:#212F84;")
        self.label_3.setText("")
        self.label_3.setObjectName("label_3")
        self.trainbtn = QtWidgets.QPushButton(self.centralwidget)
        self.trainbtn.setGeometry(QtCore.QRect(670, 540, 121, 41))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(14)
        self.trainbtn.setFont(font)
        self.trainbtn.setStyleSheet("QPushButton#trainbtn{\n"
                                    " color:#212F84;\n"
                                    "text-align:center;\n"
                                    "background:#fff; \n"
                                    "border-radius:4px;\n"
                                    "border:4px #212F84;\n"
                                    "}\n"
                                    "QPushButton#trainbtn:hover{\n"
                                    "color:#212F84;\n"
                                    "text-align:center;\n"
                                    "border-radius:4px;\n"
                                    "background:#DCDCDC;\n"
                                    "}\n"
                                    "QPushButton#trainbtn:pressed{\n"
                                    " color:green;\n"
                                    "text-align:center;\n"
                                    "background:#fff;\n"
                                    "border-radius:4px;\n"
                                    "\n"
                                    "}")
        self.trainbtn.setObjectName("trainbtn")
        self.homebtn = QtWidgets.QPushButton(self.centralwidget, clicked=lambda :self.BackWindow())

        self.homebtn.setGeometry(QtCore.QRect(10, 10, 61, 31))
        self.homebtn.setStyleSheet("image: url(:/img/arrow.png);\n"
                                   "background:#212F84; \n"
                                   "border-color:#212F84;\n"
                                   "border-radius:4px;")
        self.homebtn.setText("")
        self.homebtn.setObjectName("homebtn")
        TrainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(TrainWindow)
        QtCore.QMetaObject.connectSlotsByName(TrainWindow)

    def retranslateUi(self, TrainWindow):
        _translate = QtCore.QCoreApplication.translate
        TrainWindow.setWindowTitle(_translate("TrainWindow", "MainWindow"))
        self.trainbtn.setText(_translate("TrainWindow", "Start"))
import instimg_rc


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    TrainWindow = QtWidgets.QMainWindow()
    ui = Ui_TrainWindow()
    ui.setupUi(TrainWindow)
    TrainWindow.show()
    sys.exit(app.exec_())
