from PyQt5 import QtCore, QtGui, QtWidgets

# from testgui import Ui_MainWindow
from cv2 import CAP_DSHOW

from ui_home import *
import cv2
import mediapipe as mp
import cv2
import numpy as np
import os
from matplotlib import pyplot as plt
import time
import mediapipe as mp
import csv
import pandas as pd
import os
import pickle
import pandas as pd
import numpy as np
import warnings
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
from tensorflow.keras.callbacks import TensorBoard
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

np.seterr(divide='ignore', invalid='ignore')
from sklearn.linear_model import LogisticRegression, RidgeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier

mp_drawing = mp.solutions.drawing_utils  # Drawing helpers
mp_holistic = mp.solutions.holistic  # Mediapipe Solutions


class Ui_TrainWindow(object):
    def BackWindow(self):
        self.window = QtWidgets.QMainWindow()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self.window)
        self.window.show()

    def TestOv(self):
        def mediapipe_detection(image, model):
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)  # COLOR CONVERSION BGR 2 RGB
            image.flags.writeable = False  # Image is no longer writeable
            results = model.process(image)  # Make prediction
            image.flags.writeable = True  # Image is now writeable
            image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)  # COLOR COVERSION RGB 2 BGR
            return image, results

        def draw_styled_landmarks(image, results):
            mp_drawing.draw_landmarks(image, results.left_hand_landmarks, mp_holistic.HAND_CONNECTIONS,
                                      mp_drawing.DrawingSpec(color=(121, 22, 76), thickness=2, circle_radius=4),
                                      mp_drawing.DrawingSpec(color=(121, 44, 250), thickness=2, circle_radius=2)
                                      )
            mp_drawing.draw_landmarks(image, results.right_hand_landmarks, mp_holistic.HAND_CONNECTIONS,
                                      mp_drawing.DrawingSpec(color=(245, 117, 66), thickness=2, circle_radius=4),
                                      mp_drawing.DrawingSpec(color=(245, 66, 230), thickness=2, circle_radius=2)
                                      )

        def extract_keypoints(results):
            lh = list(np.array([[res.x, res.y, res.z] for res in
                                results.left_hand_landmarks.landmark]).flatten()) if results.left_hand_landmarks else np.ones(
                21 * 3)
            rh = list(np.array([[res.x, res.y, res.z] for res in
                                results.right_hand_landmarks.landmark]).flatten()) if results.right_hand_landmarks else np.ones(
                21 * 3)
            return np.concatenate([lh, rh])

        landmarks = ['class']
        for val in range(1, 43):
            landmarks += ['x{}'.format(val), 'y{}'.format(val), 'z{}'.format(val), 'v{}'.format(val)]

        actions = np.array(['Good','Two'])
        # videos worth of data
        no_sequences = 10

        # Videos frames in length
        sequence_length = 10

        # Folder start
        start_folder = 0

        try:
            df = pd.read_csv('newtesting01.csv')
        except:
            print("An exception occurred")
        a = df.columns[1]
        # print(a)
        with open('newtesting01.csv', mode='r', newline='') as f:
            csv_writer = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            if 'x1' in df.columns:
                cap = cv2.VideoCapture(0, CAP_DSHOW)
                # Set mediapipe model
                with mp_holistic.Holistic(min_detection_confidence=0.5, min_tracking_confidence=0.5) as holistic:
                    # NEW LOOP
                    # Loop through actions
                    for action in actions:
                        # Loop through sequences aka videos
                        for sequence in range(start_folder, start_folder + no_sequences):
                            # Loop through video length aka sequence length
                            for frame_num in range(sequence_length):

                                # Read feed
                                ret, frame = cap.read()

                                # Make detections
                                image, results = mediapipe_detection(frame, holistic)

                                # Draw landmarks
                                draw_styled_landmarks(image, results)

                                # NEW Apply wait logic
                                if frame_num == 0:
                                    cv2.putText(image, 'STARTING COLLECTION', (120, 200),
                                                cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 4, cv2.LINE_AA)
                                    cv2.putText(image,
                                                'Collecting frames for {} Video Number {}'.format(action, sequence),
                                                (15, 12),
                                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1, cv2.LINE_AA)
                                    # Show to screen
                                    cv2.imshow('OpenCV Feed', image)
                                    cv2.waitKey(500)
                                else:
                                    cv2.putText(image,
                                                'Collecting frames for {} Video Number {}'.format(action, sequence),
                                                (15, 12),
                                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1, cv2.LINE_AA)
                                    # Show to screen
                                    cv2.imshow('OpenCV Feed', image)

                                # NEW Export keypoints
                                row = list(extract_keypoints(results))
                                row.insert(0, action)
                                with open('newtesting01.csv', mode='a+', newline='') as f:
                                    csv_writer = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
                                    csv_writer.writerow(row)
                                    # Break gracefully
                                if cv2.waitKey(10) & 0xFF == ord('q'):
                                    break
                cap.release()
                cv2.destroyAllWindows()

            else:
                csv_writer.writerow(landmarks)
                cap = cv2.VideoCapture(0, CAP_DSHOW)
                # Set mediapipe model
                with mp_holistic.Holistic(min_detection_confidence=0.5, min_tracking_confidence=0.5) as holistic:
                    # NEW LOOP
                    # Loop through actions
                    for action in actions:
                        # Loop through sequences aka videos
                        for sequence in range(start_folder, start_folder + no_sequences):
                            # Loop through video length aka sequence length
                            for frame_num in range(sequence_length):

                                # Read feed
                                ret, frame = cap.read()

                                # Make detections
                                image, results = mediapipe_detection(frame, holistic)

                                # Draw landmarks
                                draw_styled_landmarks(image, results)

                                # NEW Apply wait logic
                                if frame_num == 0:
                                    cv2.putText(image, 'STARTING COLLECTION', (120, 200),
                                                cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 4, cv2.LINE_AA)
                                    cv2.putText(image,
                                                'Collecting frames for {} Video Number {}'.format(action, sequence),
                                                (15, 12),
                                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1, cv2.LINE_AA)
                                    # Show to screen
                                    cv2.imshow('OpenCV Feed', image)
                                    cv2.waitKey(500)
                                else:
                                    cv2.putText(image,
                                                'Collecting frames for {} Video Number {}'.format(action, sequence),
                                                (15, 12),
                                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1, cv2.LINE_AA)
                                    # Show to screen
                                    cv2.imshow('OpenCV Feed', image)

                                # NEW Export keypoints
                                row = list(extract_keypoints(results))
                                row.insert(0, action)
                                with open('newtesting01.csv', mode='a+', newline='') as f:
                                    csv_writer = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
                                    csv_writer.writerow(row)
                                    # Break gracefully
                                if cv2.waitKey(10) & 0xFF == ord('q'):
                                    break
                    cap.release()
                    cv2.destroyAllWindows()
        os.chdir("C:/Users/SKM/PycharmProjects/Newone/Scripts")
        df = pd.read_csv('C:/Users/SKM/PycharmProjects/Newone/newtesting01.csv')
        X = df.drop('class', axis=1)  # features
        y = df['class']  # target value
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.05)
        print(y_test)
        pipelines = {
            # 'lr': make_pipeline(StandardScaler(), LogisticRegression()),
            'rc': make_pipeline(StandardScaler(), RidgeClassifier()),
            'rf': make_pipeline(StandardScaler(), RandomForestClassifier()),
            'gb': make_pipeline(StandardScaler(), GradientBoostingClassifier()),
        }
        fit_models = {}
        for algo, pipeline in pipelines.items():
            model = pipeline.fit(X_train, y_train)
            fit_models[algo] = model
        fit_models['rf'].predict(X_test)
        with open('body_language3.pkl', 'wb') as f:
            pickle.dump(fit_models['rf'], f)

    def setupUi(self, TrainWindow):
        TrainWindow.setObjectName("TrainWindow")
        TrainWindow.resize(811, 600)
        TrainWindow.setStyleSheet("background-color:#fff;")
        self.centralwidget = QtWidgets.QWidget(TrainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(-50, 10, 931, 541))
        self.label.setStyleSheet("image: url(:/img/instructions.jpg);")
        self.label.setText("")
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(0, -1, 811, 61))
        self.label_2.setStyleSheet("background:#212F84;")
        self.label_2.setText("")
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(0, 530, 811, 71))
        self.label_3.setStyleSheet("background:#212F84;")
        self.label_3.setText("")
        self.label_3.setObjectName("label_3")
        self.trainbtn = QtWidgets.QPushButton(self.centralwidget, clicked=lambda: self.TestOv())
        self.trainbtn.setGeometry(QtCore.QRect(670, 540, 121, 41))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(14)
        self.trainbtn.setFont(font)
        self.trainbtn.setStyleSheet("QPushButton#trainbtn{\n"
                                    " color:#212F84;\n"
                                    "text-align:center;\n"
                                    "background:#fff; \n"
                                    "border-radius:4px;\n"
                                    "border:4px #212F84;\n"
                                    "}\n"
                                    "QPushButton#trainbtn:hover{\n"
                                    "color:#212F84;\n"
                                    "text-align:center;\n"
                                    "border-radius:4px;\n"
                                    "background:#DCDCDC;\n"
                                    "}\n"
                                    "QPushButton#trainbtn:pressed{\n"
                                    " color:green;\n"
                                    "text-align:center;\n"
                                    "background:#fff;\n"
                                    "border-radius:4px;\n"
                                    "\n"
                                    "}")
        self.trainbtn.setObjectName("trainbtn")
        self.homebtn = QtWidgets.QPushButton(self.centralwidget)
        self.homebtn.clicked.connect(self.BackWindow)
        self.homebtn.clicked.connect(TrainWindow.close)
        self.homebtn.setGeometry(QtCore.QRect(10, 10, 61, 31))
        self.homebtn.setStyleSheet("image: url(:/img/arrow.png);\n"
                                   "background:#212F84; \n"
                                   "border-color:#212F84;\n"
                                   "border-radius:4px;")
        self.homebtn.setText("")
        self.homebtn.setObjectName("homebtn")
        TrainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(TrainWindow)
        QtCore.QMetaObject.connectSlotsByName(TrainWindow)

    def retranslateUi(self, TrainWindow):
        _translate = QtCore.QCoreApplication.translate
        TrainWindow.setWindowTitle(_translate("TrainWindow", "MainWindow"))
        self.trainbtn.setText(_translate("TrainWindow", "Start"))

        TrainWindow.setWindowFlags(QtCore.Qt.FramelessWindowHint)
        TrainWindow.setAttribute(QtCore.Qt.WA_TranslucentBackground)


import instimg_rc

if __name__ == "__main__":
    import sys

    app = QtWidgets.QApplication(sys.argv)
    TrainWindow = QtWidgets.QMainWindow()
    ui = Ui_TrainWindow()
    ui.setupUi(TrainWindow)
    TrainWindow.show()
    sys.exit(app.exec_())
