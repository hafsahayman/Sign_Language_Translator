# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'homeWtVEzk.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

import hand_rc

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(535, 288)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.centralwidget.setAutoFillBackground(False)
        self.centralwidget.setStyleSheet(u"background:rgba(0,0,0,0);")
        self.main_frame = QFrame(self.centralwidget)
        self.main_frame.setObjectName(u"main_frame")
        self.main_frame.setGeometry(QRect(0, 100, 531, 181))
        self.main_frame.setStyleSheet(u"background:#212F84;\n"
                                      "border-radius:20px;\n"
                                      "box-shadow: 5px 10px #D5D5D6;\n"
                                      "\n"
                                      "")
        self.main_frame.setFrameShape(QFrame.StyledPanel)
        self.main_frame.setFrameShadow(QFrame.Raised)
        self.train = QPushButton(self.main_frame)
        self.train.setObjectName(u"train")
        self.train.setGeometry(QRect(40, 60, 131, 61))
        font = QFont()
        font.setFamily(u"Comic Sans MS")
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.train.setFont(font)
        self.train.setStyleSheet(u"QPushButton#train{\n"
                                 " color:#212F84;\n"
                                 "text-align:center;\n"
                                 "background:#fff;\n"
                                 "border-radius:4px;\n"
                                 "border-color:#212F84;\n"
                                 "}\n"
                                 "QPushButton#train:hover{\n"
                                 "color:#212F84;\n"
                                 "text-align:center;\n"
                                 "border-radius:4px;\n"
                                 "background:#DCDCDC;\n"
                                 "}\n"
                                 "QPushButton#train:pressed{\n"
                                 " color:green;\n"
                                 "text-align:center;\n"
                                 "background:#DCDCDC;\n"
                                 "border-radius:4px;\n"
                                 "\n"
                                 "}\n"
                                 "\n"
                                 "\n"
                                 "\n"
                                 "\n"
                                 "\n"
                                 "")
        self.test = QPushButton(self.main_frame)
        self.test.setObjectName(u"test")
        self.test.setGeometry(QRect(190, 60, 141, 61))
        self.test.setFont(font)
        self.test.setStyleSheet(u"QPushButton#test{\n"
                                " color:#212F84;\n"
                                "text-align:center;\n"
                                "background:#fff;\n"
                                "border-radius:4px;\n"
                                "border-color:#212F84;\n"
                                "}\n"
                                "QPushButton#test:hover{\n"
                                "color:#212F84;\n"
                                "text-align:center;\n"
                                "border-radius:4px;\n"
                                "background:#DCDCDC;\n"
                                "}\n"
                                "QPushButton#test:pressed{\n"
                                " color:green;\n"
                                "text-align:center;\n"
                                "background:#DCDCDC;\n"
                                "border-radius:4px;\n"
                                "\n"
                                "}\n"
                                "\n"
                                "\n"
                                "\n"
                                "\n"
                                "\n"
                                "")
        self.check = QPushButton(self.main_frame)
        self.check.setObjectName(u"check")
        self.check.setGeometry(QRect(350, 60, 141, 61))
        font1 = QFont()
        font1.setFamily(u"Comic Sans MS")
        font1.setPointSize(12)
        font1.setBold(True)
        font1.setWeight(75)
        self.check.setFont(font1)
        self.check.setStyleSheet(u"QPushButton#check{\n"
                                 " color:#212F84;\n"
                                 "text-align:center;\n"
                                 "background:#fff;\n"
                                 "border-radius:4px;\n"
                                 "border-color:#212F84;\n"
                                 "}\n"
                                 "QPushButton#check:hover{\n"
                                 "color:#212F84;\n"
                                 "text-align:center;\n"
                                 "border-radius:4px;\n"
                                 "background:#DCDCDC;\n"
                                 "}\n"
                                 "QPushButton#check:pressed{\n"
                                 " color:green;\n"
                                 "text-align:center;\n"
                                 "background:#DCDCDC;\n"
                                 "border-radius:4px;\n"
                                 "\n"
                                 "}\n"
                                 "\n"
                                 "\n"
                                 "\n"
                                 "\n"
                                 "\n"
                                 "")
        self.hands = QFrame(self.centralwidget)
        self.hands.setObjectName(u"hands")
        self.hands.setGeometry(QRect(30, 20, 461, 131))
        self.hands.setStyleSheet(u"image: url(:/img/welcome.png);\n"
                                 "")
        self.hands.setFrameShape(QFrame.StyledPanel)
        self.hands.setFrameShadow(QFrame.Raised)
        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.train.setText(QCoreApplication.translate("MainWindow", u"TRAIN", None))
        self.test.setText(QCoreApplication.translate("MainWindow", u"TEST", None))
        self.check.setText(QCoreApplication.translate("MainWindow", u"CHECK SIGNS", None))
    # retranslateUi

