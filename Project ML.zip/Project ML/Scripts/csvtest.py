import os
import pandas as pd
os.chdir("C:/Users/SKM/PycharmProjects/Newone")
a=os.listdir()
df = pd.read_csv('C:/Users/SKM/PycharmProjects/Newone/newestings09.csv')
a=df.head()
print(a)