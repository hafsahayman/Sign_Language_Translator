import sys
import os
import platform
from PySide2 import QtCore, QtGui, QtWidgets
from PySide2.QtCore import (QCoreApplication, QDate, QDateTime, QMetaObject, QObject, QPoint, QRect, QSize, QTime, QUrl,
                            Qt)
from PySide2.QtGui import (QBrush, QColor, QConicalGradient, QCursor, QFont, QFontDatabase, QIcon, QKeySequence,
                           QLinearGradient, QPalette, QPainter, QPixmap, QRadialGradient)
from PySide2.QtWidgets import *
from PyQt5 import QtWidgets

from ui_instruct import Ui_TrainWindow

# from ui_home import *
import testgui


class MainWindow(QMainWindow):
    def OpensWindow(self):
        self.window = QtWidgets.QMainWindow()
        self.ui = Ui_TrainWindow()
        self.ui.setupUi(self.window)
        self.window.show()

    def __init__(self):
        self.home = testgui
        QMainWindow.__init__(self)
        self.ui = self.home.Ui_MainWindow()
        self.ui.setupUi(self)
        self.setWindowFlags(QtCore.Qt.FramelessWindowHint)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)

        self.shadow = QGraphicsDropShadowEffect(self)
        self.shadow.setBlurRadius(20)
        self.shadow.setXOffset(0)
        self.shadow.setYOffset(0)
        self.shadow.setColor(QColor(0, 0, 0, 120))
        self.ui.centralwidget.setGraphicsEffect(self.shadow)

        # close button
        self.ui.close.clicked.connect(lambda: self.close())
        self.ui.close.clicked.connect(self.show_dialog)

        # train window
        self.ui.train.clicked.connect(self.open_Window)

    def show_dialog(self):
        result = QMessageBox.question(self, 'Exit', 'Are you sure you want to close the application?',
                                      QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if result == QMessageBox.Yes:
            print('Yes Clicked')
            QtWidgets.qApp.quit()

        else:
            print('No Clicked')

     #self.show()


if __name__ == "__main__":
    import sys

    app = QtWidgets.QApplication(sys.argv)
    OpenWindow1 = QtWidgets.QMainWindow()
    ui = testgui.Ui_MainWindow()
    ui.setupUi(OpenWindow1)
    OpenWindow1.show()
    sys.exit(app.exec_())
