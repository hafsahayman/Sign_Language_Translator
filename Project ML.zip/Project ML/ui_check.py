from PyQt5 import QtCore, QtGui, QtWidgets
import csv
import os
import numpy as np
import pandas as pd

df = pd.read_csv('C:/Users/SKM/PycharmProjects/Newone/newtesting01.csv',error_bad_lines=False)


class Ui_CheckWindow(object):

    def BacksWindow(self):
        from ui_home import Ui_MainWindow
        self.window = QtWidgets.QMainWindow()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self.window)
        self.window.show()

    def setupUi(self, CheckWindow):
        CheckWindow.setObjectName("CheckWindow")
        CheckWindow.resize(579, 660)
        self.centralwidget = QtWidgets.QWidget(CheckWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(0, 0, 581, 661))
        self.label.setStyleSheet("background:#212F84;")
        self.label.setText("")
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(70, 80, 441, 501))
        self.label_2.setStyleSheet("background:#fff;\n"
                                   "border-radius:10px;")
        self.label_2.setText("")
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(150, 110, 281, 71))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(24)
        font.setBold(False)
        font.setWeight(50)
        self.label_3.setFont(font)
        self.label_3.setStyleSheet("color:#212F84;")
        self.label_3.setObjectName("label_3")
        self.sign = QtWidgets.QLabel(self.centralwidget)
        self.sign.setGeometry(QtCore.QRect(120, 80, 371, 301))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(16)
        self.sign.setFont(font)
        self.sign.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.sign.setStyleSheet("color:#212F84;")
        self.sign.setTextFormat(QtCore.Qt.PlainText)
        self.sign.setWordWrap(True)
        self.sign.setIndent(19)
        self.sign.setObjectName("sign")
        self.pushButton = QtWidgets.QPushButton(self.centralwidget, clicked=lambda: self.BacksWindow())
        # self.pushButton.clicked.connect(CheckWindow.BacksWindow)
        self.pushButton.clicked.connect(CheckWindow.close)
        self.pushButton.setGeometry(QtCore.QRect(10, 10, 61, 41))
        self.pushButton.setStyleSheet("image: url(:/img/arrow.png);\n"
                                      "background:#212F84; \n"
                                      "border-color:#212F84;\n"
                                      "border-radius:4px;")
        self.pushButton.setText("")
        self.pushButton.setObjectName("pushButton")
        CheckWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(CheckWindow)
        QtCore.QMetaObject.connectSlotsByName(CheckWindow)
        my_list = df['class'].unique()
        self.sign.setText(str(my_list))

    # my_list = ['hey', 'hr', 'ok', 'a', 'b', 'c', 'd', 'e']
    # self.sign.setText(str(my_list))

    def retranslateUi(self, CheckWindow):
        _translate = QtCore.QCoreApplication.translate
        CheckWindow.setWindowTitle(_translate("CheckWindow", "MainWindow"))
        self.label_3.setText(_translate("CheckWindow", "Trained Signs"))
        self.sign.setText(_translate("CheckWindow", "TextLabel"))

        CheckWindow.setWindowFlags(QtCore.Qt.FramelessWindowHint)
        CheckWindow.setAttribute(QtCore.Qt.WA_TranslucentBackground)


import arrow_rc

if __name__ == "__main__":
    import sys

    app = QtWidgets.QApplication(sys.argv)
    CheckWindow = QtWidgets.QMainWindow()
    ui = Ui_CheckWindow()
    ui.setupUi(CheckWindow)
    CheckWindow.show()
    sys.exit(app.exec_())
