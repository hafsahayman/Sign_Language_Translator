import sys
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtGui import QColor
from PyQt5.QtWidgets import QGraphicsDropShadowEffect
from PyQt5.QtWidgets import QMessageBox
import pickle
import cv2
import numpy as np
import os
import pyttsx3
from matplotlib import pyplot as plt
import time
import mediapipe as mp
import csv
import warnings
import pandas as pd
import warnings
import pyttsx3
import hand_rc

speak = pyttsx3.init()
voices = speak.getProperty('voices')
speak.setProperty('voice', voices[1].id)
speak.setProperty('volume', 0.7)
speak.setProperty('rate', 150)


class Ui_MainWindow(object):

    def OpensWindow(self):
        from ui_instruct import Ui_TrainWindow
        self.window = QtWidgets.QMainWindow()
        self.ui = Ui_TrainWindow()
        self.ui.setupUi(self.window)
        self.window.show()

    def ChecksWindow(self):
        from ui_check import Ui_CheckWindow
        self.window = QtWidgets.QMainWindow()
        self.ui = Ui_CheckWindow()
        self.ui.setupUi(self.window)
        self.window.show()

    def Test(self):
        speak.say("Welcome")
        warnings.filterwarnings("ignore")
        cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
        with open("C:/Users/SKM/PycharmProjects/Newone/Scripts/body_language3.pkl", 'rb') as f:
            model = pickle.load(f)
        mp_holistic = mp.solutions.holistic  # Holistic model
        mp_drawing = mp.solutions.drawing_utils  # Drawing utilities

        def mediapipe_detection(image, model):
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)  # COLOR CONVERSION BGR 2 RGB
            image.flags.writeable = False  # Image is no longer writeable
            results = model.process(image)  # Make prediction
            image.flags.writeable = True  # Image is now writeable
            image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)  # COLOR COVERSION RGB 2 BGR
            return image, results

        def draw_styled_landmarks(image, results):
            # Draw left hand connections
            mp_drawing.draw_landmarks(image, results.left_hand_landmarks, mp_holistic.HAND_CONNECTIONS,
                                      mp_drawing.DrawingSpec(color=(121, 22, 76), thickness=2, circle_radius=4),
                                      mp_drawing.DrawingSpec(color=(121, 44, 250), thickness=2, circle_radius=2)
                                      )
            # Draw right hand connections
            mp_drawing.draw_landmarks(image, results.right_hand_landmarks, mp_holistic.HAND_CONNECTIONS,
                                      mp_drawing.DrawingSpec(color=(245, 117, 66), thickness=2, circle_radius=4),
                                      mp_drawing.DrawingSpec(color=(245, 66, 230), thickness=2, circle_radius=2)
                                      )

        def extract_keypoints(results):
            lh = np.array([[res.x, res.y, res.z] for res in
                           results.left_hand_landmarks.landmark]).flatten() if results.left_hand_landmarks else np.zeros(
                21 * 3)
            rh = np.array([[res.x, res.y, res.z] for res in
                           results.right_hand_landmarks.landmark]).flatten() if results.right_hand_landmarks else np.zeros(
                21 * 3)
            return np.concatenate([lh, rh])

        with mp_holistic.Holistic(min_detection_confidence=0.5, min_tracking_confidence=0.5) as holistic:
            while cap.isOpened():
                ret, frame = cap.read()

                image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                image.flags.writeable = False

                results = holistic.process(image)
                # print(results.face_landmarks)

                # face_landmarks, pose_landmarks, left_hand_landmarks, right_hand_landmarks

                # Recolor image back to BGR for rendering
                image.flags.writeable = True
                image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

                # Make detections
                row = list(extract_keypoints(results))
                # Draw landmarks
                draw_styled_landmarks(image, results)
                # Make Detections
                X = pd.DataFrame([row])
                body_language_class = model.predict(X)[0]
                # speak.say(body_language_class)
                # speak.runAndWait()
                # print(body_language_class, body_language_prob)
                cv2.rectangle(image, (0, 0), (250, 60), (245, 117, 16), -1)

                # Display Class
                cv2.putText(image, 'CLASS'
                            , (95, 12), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                cv2.putText(image, body_language_class.split(' ')[0]
                            , (90, 40), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2, cv2.LINE_AA)

                cv2.imshow('Raw Webcam Feed', image)

                if cv2.waitKey(10) & 0xFF == ord('q'):
                    break

        cap.release()
        cv2.destroyAllWindows()

    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(554, 286)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setAutoFillBackground(False)
        self.centralwidget.setStyleSheet("background:rgba(0,0,0,0);")
        self.centralwidget.setObjectName("centralwidget")
        self.main_frame = QtWidgets.QFrame(self.centralwidget)
        self.main_frame.setGeometry(QtCore.QRect(10, 90, 531, 181))
        self.main_frame.setStyleSheet("background:#212F84;\n"
                                      "border-radius:20px;\n"
                                      "box-shadow: 5px 10px #D5D5D6;\n"
                                      "\n"
                                      "")
        self.main_frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.main_frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.main_frame.setObjectName("main_frame")
        self.train = QtWidgets.QPushButton(MainWindow)
        # self.train.clicked.connect(self.OpensWindow)
        # self.train.clicked.connect(MainWindow.close)
        self.train.setGeometry(QtCore.QRect(40, 150, 131, 61))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.train.setFont(font)
        self.train.setStyleSheet("QPushButton#train{\n"
                                 " color:#212F84;\n"
                                 "text-align:center;\n"
                                 "background:#fff;\n"
                                 "border-radius:4px;\n"
                                 "border-color:#212F84;\n"
                                 "}\n"
                                 "QPushButton#train:hover{\n"
                                 "color:#212F84;\n"
                                 "text-align:center;\n"
                                 "border-radius:4px;\n"
                                 "background:#DCDCDC;\n"
                                 "}\n"
                                 "QPushButton#train:pressed{\n"
                                 " color:green;\n"
                                 "text-align:center;\n"
                                 "background:#DCDCDC;\n"
                                 "border-radius:4px;\n"
                                 "\n"
                                 "}\n"
                                 "\n"
                                 "\n"
                                 "\n"
                                 "\n"
                                 "\n"
                                 "")
        self.train.setObjectName("train")
        self.test = QtWidgets.QPushButton(self.main_frame, clicked=lambda: self.Test())
        self.test.setGeometry(QtCore.QRect(190, 60, 141, 61))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.test.setFont(font)
        self.test.setStyleSheet("QPushButton#test{\n"
                                " color:#212F84;\n"
                                "text-align:center;\n"
                                "background:#fff;\n"
                                "border-radius:4px;\n"
                                "border-color:#212F84;\n"
                                "}\n"
                                "QPushButton#test:hover{\n"
                                "color:#212F84;\n"
                                "text-align:center;\n"
                                "border-radius:4px;\n"
                                "background:#DCDCDC;\n"
                                "}\n"
                                "QPushButton#test:pressed{\n"
                                " color:green;\n"
                                "text-align:center;\n"
                                "background:#DCDCDC;\n"
                                "border-radius:4px;\n"
                                "\n"
                                "}\n"
                                "\n"
                                "\n"
                                "\n"
                                "\n"
                                "\n"
                                "")
        self.test.setObjectName("test")
        self.check = QtWidgets.QPushButton(self.main_frame, clicked=lambda: self.ChecksWindow())
        # self.check.clicked.connect(self.ChecksWindow)
        self.check.clicked.connect(MainWindow.close)
        self.check.setGeometry(QtCore.QRect(350, 60, 141, 61))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.check.setFont(font)
        self.check.setStyleSheet("QPushButton#check{\n"
                                 " color:#212F84;\n"
                                 "text-align:center;\n"
                                 "background:#fff;\n"
                                 "border-radius:4px;\n"
                                 "border-color:#212F84;\n"
                                 "}\n"
                                 "QPushButton#check:hover{\n"
                                 "color:#212F84;\n"
                                 "text-align:center;\n"
                                 "border-radius:4px;\n"
                                 "background:#DCDCDC;\n"
                                 "}\n"
                                 "QPushButton#check:pressed{\n"
                                 " color:green;\n"
                                 "text-align:center;\n"
                                 "background:#DCDCDC;\n"
                                 "border-radius:4px;\n"
                                 "\n"
                                 "}\n"
                                 "\n"
                                 "\n"
                                 "\n"
                                 "\n"
                                 "\n"
                                 "")
        self.check.setObjectName("check")
        # self.close = QtWidgets.QPushButton(MainWindow, clicked=lambda: self.show_dialog())
        self.close = QtWidgets.QPushButton(MainWindow, clicked=lambda: self.show_dialog())
        self.train.clicked.connect(self.OpensWindow)
        self.train.clicked.connect(MainWindow.close)
        # self.close.clicked.connect(MainWindow.showdialog)
        self.close.setGeometry(QtCore.QRect(490, 105, 31, 21))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(14)
        self.close.setFont(font)
        self.close.setStyleSheet("QPushButton#close{\n"
                                 " color:#fff;\n"
                                 "text-align:center;\n"
                                 "background:#212F84;\n"
                                 "border-radius:4px;\n"
                                 "border-color:#212F84;\n"
                                 "}\n"
                                 "QPushButton#close:pressed{\n"
                                 " color:green;\n"
                                 "text-align:center;\n"
                                 "background:#DCDCDC;\n"
                                 "border-radius:4px;\n"
                                 "\n"
                                 "}\n"
                                 "\n"
                                 "\n"
                                 "\n"
                                 "\n"
                                 "\n"
                                 "")
        self.close.setObjectName("close")
        self.hands = QtWidgets.QFrame(self.centralwidget)
        self.hands.setGeometry(QtCore.QRect(40, 10, 461, 131))
        self.hands.setStyleSheet("image: url(:/img/welcome.png);\n"
                                 "")
        self.hands.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.hands.setFrameShadow(QtWidgets.QFrame.Raised)
        self.hands.setObjectName("hands")
        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)
        # self.train.clicked.connect(self.OpensWindow)
        # self.train.clicked.connect(MainWindow.close)

    def show_dialog(self):
        msg = QMessageBox()
        msg.setWindowTitle("Close")
        msg.setText("Are you sure ")
        msg.setStandardButtons(QMessageBox.Yes | QMessageBox.Cancel)
        msg.buttonClicked.connect(self.popup_button)
        x = msg.exec_()
        # print(x)
        # print('Yes Clicked')
        # QtWidgets.qApp.quit()

    def popup_button(self, i):
        if i.text() == '&Yes':
            QtWidgets.qApp.quit()

    def showDialog(self):
        result = QMessageBox.question(self, 'Exit', 'Are you sure you want to close the application?',
                                      QMessageBox.Yes | QMessageBox.Cancel, QMessageBox.Cancel)
        if result == '&Yes':
            print('Yes Clicked')
            QtWidgets.qApp.quit()
        else:
            print('No Clicked')

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.train.setText(_translate("MainWindow", "TRAIN"))
        self.test.setText(_translate("MainWindow", "TEST"))
        self.check.setText(_translate("MainWindow", "CHECK SIGNS"))
        self.close.setText(_translate("MainWindow", "X"))

        MainWindow.setWindowFlags(QtCore.Qt.FramelessWindowHint)
        MainWindow.setAttribute(QtCore.Qt.WA_TranslucentBackground)


if __name__ == "__main__":
    import sys

    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
